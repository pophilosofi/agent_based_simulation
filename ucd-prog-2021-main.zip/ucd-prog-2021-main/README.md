# ucd-prog-2021
Simulation project for the module Programming for Social Scientists at UCD, 2021-22
